<?php

namespace App\Http\Controllers;

use App\Models\Belajar;
use Illuminate\Http\Request;
use App\Http\Controllers\BelajarController;
use Illuminate\Support\Facades\Http;

class BelajarController extends Controller
{

    public function read()
    {
        $url = 'http://localhost:8000/api/penggunas';
        $response = Http::get($url);
        $data = $response->json();        
        return view('index', compact(['data']));
    }

    public function create()
    {
        return view('add');
    }

    public function index()
    {
        //
    }

    public function store(Request $request)
    {
        // $this->validate($request, [
        //     'nama' => 'required|string',
        //     'umur' => 'required|int',
        //     'foto' => 'required'
        // ]);

        $foto = $request->file('foto');
        $filename = date('Ymd-His').'.'.$foto->getClientOriginalExtension();
        $foto->move(public_path('assets/uploads/'), $filename);

        $data = [
            'nama' => $request->nama,
            'umur' => $request->umur,
            'foto' => url('assets/uploads/'.$filename)
        ];

        if($data)
        {
            $url = 'http://localhost:8000/api/penggunas';
            $response = Http::post($url, $data);
            return redirect()
                ->route('read')
                ->with([
                    'success' => 'Data Berhasil Ditambahkan.'
                    // 'success' => $response
                ]);
        } 
        else 
        {
            return redirect()
                ->back()
                ->withInput()
                ->with([
                    'error' => 'Terdapat Kesalahan, silahkan ulangi.'
                ]);
        }

        // return redirect()->back()->with('success','Sucessfully changed User Information');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Belajar  $belajar
     * @return \Illuminate\Http\Response
     */
    public function show(Belajar $belajar)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Belajar  $belajar
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $url = 'http://localhost:8000/api/penggunas/'.$id;
        $response = Http::get($url);
        $data = $response->json();
        // dd($data['data']);
        return view('edit')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Belajar  $belajar
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if($request->file('foto') == "")
        {
            $data = [
                'nama' => $request->nama,
                'umur' => $request->umur,
                'foto' => $request->foto_lama
            ];
        }
        else
        {
            $foto = $request->file('foto');
            $filename = date('Ymd-His').'.'.$foto->getClientOriginalExtension();
            $foto->move(public_path('assets/uploads/'), $filename);

            $data = [
                'nama' => $request->nama,
                'umur' => $request->umur,
                'foto' => url('assets/uploads/'.$filename)
            ];
        }
        
        if($data)
        {
            $url = 'http://localhost:8000/api/penggunas/'.$id;
            $response = Http::put($url, $data);
            return redirect()
                ->route('read')
                ->with([
                    'success_edit' => 'Data dengan ID '.$id.' Berhasil Diubah.'
                ]);
            // dd($response);  
        } 
        else 
        {
            return redirect()
                ->back()
                ->withInput()
                ->with([
                    'error' => 'Terdapat Kesalahan, silahkan ulangi.'
                ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Belajar  $belajar
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $url = 'http://localhost:8000/api/penggunas/'.$id;
        $response = Http::delete($url);
        return redirect()
            ->route('read')
            ->with([
                'success_delete' => 'Data dengan ID '.$id.' berhasil dihapus.'
            ]);
    }
}
